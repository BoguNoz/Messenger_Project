﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Messager_Project.DTO.MessageEmotes
{
    public class MessageEmotesDto
    {
        // Jeśli musisz coś dodać Michał dodaj
    }
}
